-- CREATE DATABASE prescriptions_rx

-- NOTE: If you are using MySQL Workbench, make sure anywhere where there is 'IDENTITY(1,1)' is replaced with 'AUTO_INCREMENT'

-- TABLE 1
CREATE TABLE doctors (
    SSN CHAR(10),
    last_name VARCHAR(15) NOT NULL,
    first_name VARCHAR(15) NOT NULL,
    specialty VARCHAR(20),
    years_of_experience INT,

	PRIMARY KEY (SSN)
);

-- TABLE 2
CREATE TABLE patients (
    SSN CHAR(10),
    last_name VARCHAR(15) NOT NULL,
    first_name VARCHAR(15) NOT NULL,
    city VARCHAR(15),
    street VARCHAR(15),
    address VARCHAR(15),
    birth_date DATE,
    primary_doctorSSN CHAR(10),

    PRIMARY KEY (SSN),

    FOREIGN KEY (primary_doctorSSN) REFERENCES doctors(SSN)
);

-- TABLE 3
CREATE TABLE pharmaceutical_companies (
    name VARCHAR(50),
    phone_number VARCHAR(16),

	PRIMARY KEY (name)
);

-- TABLE 4
CREATE TABLE drugs (
    trade_name VARCHAR(50),
    company_name VARCHAR(50),

    PRIMARY KEY (trade_name),


    FOREIGN KEY (company_name) REFERENCES pharmaceutical_companies(name)
);

-- TABLE 5
CREATE TABLE drug_formulas (
    formulaID INT IDENTITY (1,1), -- in MySQL Workbench replace 'IDENTITY (1,1)' with 'AUTO_INCREMENT'
    trade_name VARCHAR(50),
    active_ingredients TEXT,
    strength VARCHAR(50),
    dosage_form VARCHAR(50),
    route_of_administration VARCHAR(100),
    preparation_instructions TEXT,

	PRIMARY KEY (formulaID),

    FOREIGN KEY (trade_name) REFERENCES drugs(trade_name)
);

-- TABLE 6
CREATE TABLE pharmacies (
    name VARCHAR(50),
    city VARCHAR(50),
    street VARCHAR(50),
    address VARCHAR(50),
    phone_number VARCHAR(15),

	PRIMARY KEY (name)
);

-- TABLE 7
CREATE TABLE pharmacy_drugs (
    pharmacy_name VARCHAR(50),
    drug_trade_name VARCHAR(50),
    price DECIMAL(10, 2),

    PRIMARY KEY (pharmacy_name, drug_trade_name),

    FOREIGN KEY (pharmacy_name) REFERENCES pharmacies(name),
    FOREIGN KEY (drug_trade_name) REFERENCES drugs(trade_name),
);

-- TABLE 8
CREATE TABLE prescriptions (
    prescriptionID INT IDENTITY (1,1), -- in MySQL Workbench replace 'IDENTITY (1,1)' with 'AUTO_INCREMENT'
    patientSSN CHAR(10),
    doctorSSN CHAR(10),
    drug_trade_name VARCHAR(50),
    date DATE,
    quantity INT,

	PRIMARY KEY (prescriptionID),

    FOREIGN KEY (patientSSN) REFERENCES Patients(SSN),
    FOREIGN KEY (doctorSSN) REFERENCES Doctors(SSN),
    FOREIGN KEY (drug_trade_name) REFERENCES drugs(trade_name)
);

-- TABLE 9
CREATE TABLE contracts (
    contractID INT IDENTITY (1,1), -- in MySQL Workbench replace 'IDENTITY (1,1)' with 'AUTO_INCREMENT'
    pharmacy_name VARCHAR(50),
    company_name VARCHAR(50),
    start_date DATE,
    end_date DATE,
    supervisorSSN CHAR(10),

	PRIMARY KEY (contractID),

    FOREIGN KEY (pharmacy_name) REFERENCES pharmacies(name),
    FOREIGN KEY (company_name) REFERENCES pharmaceutical_companies(name),
    FOREIGN KEY (supervisorSSN) REFERENCES doctors(SSN)
);

-- TABLE 10
CREATE TABLE clause_names (
    clause_nameID INT IDENTITY (1,1), -- in MySQL Workbench replace 'IDENTITY (1,1)' with 'AUTO_INCREMENT'
    clause_name VARCHAR(20) NOT NULL,

    PRIMARY KEY (clause_nameID)
);

-- TABLE 11
CREATE TABLE contract_clauses (
    clauseID INT IDENTITY (1,1), -- in MySQL Workbench replace 'IDENTITY (1,1)' with 'AUTO_INCREMENT'
    contractID INT,
    clause_nameID INT NOT NULL,
    clause_text TEXT,

	PRIMARY KEY (clauseID),

    FOREIGN KEY (contractID) REFERENCES contracts(contractID),
	FOREIGN KEY (clause_nameID) REFERENCES clause_names(clause_nameID)
);

-- TABLE 12
CREATE TABLE payment_methods (
    methodID INT IDENTITY (1,1), -- in MySQL Workbench replace 'IDENTITY (1,1)' with 'AUTO_INCREMENT'
    method_name VARCHAR(50) NOT NULL,

	PRIMARY KEY (methodID)
);

-- TABLE 13
-- These are purchases between Pharmacies and Patients
CREATE TABLE purchases (
    purchaseID INT IDENTITY (1,1), -- in MySQL Workbench replace 'IDENTITY (1,1)' with 'AUTO_INCREMENT'
    patientSSN CHAR(10),
    pharmacy_name VARCHAR(50),
    drug_trade_name VARCHAR(50),
	purchase_date DATE,
    quantity INT,
    price DECIMAL(10, 2),
    payment_methodID INT,

	PRIMARY KEY (purchaseID),

    FOREIGN KEY (patientSSN) REFERENCES patients(SSN),
    FOREIGN KEY (pharmacy_name) REFERENCES pharmacies(name),
    FOREIGN KEY (drug_trade_name) REFERENCES drugs(trade_name),
	FOREIGN KEY (payment_methodID) REFERENCES payment_methods(methodID)
);

-- TABLE 14
-- Purchases between Pharmacies and Pharmaceutical Companies
CREATE TABLE pharmacy_purchases (
    purchaseID INT IDENTITY (1,1), -- in MySQL Workbench replace 'IDENTITY (1,1)' with 'AUTO_INCREMENT'
    pharmacy_name VARCHAR(50),
    company_name VARCHAR(50),
    drug_trade_name VARCHAR(50),
    purchase_date DATE,
    quantity INT,
    price DECIMAL(10, 2),
    payment_methodID INT,

	PRIMARY KEY (purchaseID),

    FOREIGN KEY (pharmacy_name) REFERENCES pharmacies(name),
    FOREIGN KEY (company_name) REFERENCES pharmaceutical_companies(name),
    FOREIGN KEY (drug_trade_name) REFERENCES drugs(trade_name),
    FOREIGN KEY (payment_methodID) REFERENCES payment_methods(methodID)
);