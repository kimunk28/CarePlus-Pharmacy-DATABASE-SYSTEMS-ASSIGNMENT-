INSERT INTO doctors (SSN, last_name, first_name, specialty, years_of_experience) VALUES
	('1000000000', 'Bwembya', 'Ruth', 'Dental Surgeon', 15),
	('1000000001', 'Sumuchimba', 'Kuunda', 'Public Health', 10),
	('1000000002', 'Goma', 'Gabriel', 'Neurology', 8),
	('1000000003', 'Chipungu', 'Jane', 'Opthalmology', 12),
	('1000000004', 'Mambwe', 'Mwaba', 'Medicine & Surgery', 7),
	('1000000005', 'Chooma', 'Miyoba', 'Ophthalmology', 9),
	('1000000006', 'Chomba', 'Gloria', 'General Surgery', 14),
	('1000000007', 'Munkombwe', 'Sebenza', 'Internal Medicine', 11),
	('1000000008', 'Kunda', 'Josiah', 'Neurology', 5),
	('1000000009', 'Mulenga', 'Seingjie', 'Psychiatry', 6);


INSERT INTO patients (SSN, last_name, first_name, city, street, address, birth_date, primary_doctorSSN) VALUES
	('1000000010', 'Mwila', 'Chomba', 'Lusaka', 'Chimbotela Road', '1001', '1999-01-01', '1000000008'),
	('1000000011', 'Mukabe', 'Isreal', 'Ndola', 'Kalengwa', '1002', '2001-02-15', '1000000005'),
	('1000000012', 'Kangwa', 'Chilando. S', 'Kitwe', 'Zircon Ave', '1003', '2001-03-22', '1000000009'),
	('1000000013', 'Ngosa', 'Frank', 'Livingstone', 'Victoria Road', '1004', '2000-04-30', '1000000007'),
	('1000000014', 'Nanyangwe', 'Twiza', 'Chingola', 'Nyanji Road', '1005', '2002-05-10', '1000000006'),
	('1000000015', 'Mulenga', 'Abigail', 'Kabwe', 'Misanse Way', '1006', '2001-06-18', '1000000000'),
	('1000000016', 'Mbumba', 'Lyness', 'Mongu', 'Rice Road', '1007', '2003-07-25', '1000000001'),
	('1000000017', 'Mukabe', 'Isreal', 'Kasama', 'Main Street', '1008', '2003-08-12', '1000000002'),
	('1000000018', 'Lwembe', 'Vincent', 'Chipata', 'Sinda Street', '1009', '2003-09-03', '1000000003'),
	('1000000019', 'Kalenga', 'Stanley', 'Mufulira', 'Lunsonga', '1010', '2002-10-20', '1000000004');


INSERT INTO pharmaceutical_companies (name, phone_number) VALUES
	('Lusaka Plc', '+260-757-123-120'),
	('Copperbelt Plc', '+260-767-123-121'),
	('Luapula Plc', '+260-777-123-122'),
	('Central Plc', '+260-977-123-123');


INSERT INTO drugs (trade_name, company_name) VALUES
	('Panadol', 'Lusaka Plc'),
	('Aspirin', 'Copperbelt Plc'),
	('Ibuprofen', 'Luapula Plc'),
	('Cough Syrup', 'Central Plc'),
	('Amoxicillin', 'Central Plc'),
	('Cetirizine', 'Luapula Plc'),
	('Paracetamol', 'Copperbelt Plc'),
	('Metformin', 'Lusaka Plc'),
	('Lisinopril', 'Lusaka Plc'),
	('Simvastatin', 'Copperbelt Plc');


INSERT INTO drug_formulas (trade_name, active_ingredients, strength, dosage_form, route_of_administration, preparation_instructions) VALUES
	('Panadol', 'Katapa', '500mg', 'Tablet', 'Oral', 'Take one tablet every 4-6 hours'),
	('Aspirin', 'Kalembula', '100mg', 'Tablet', 'Oral', 'Take one tablet daily with food'),
	('Ibuprofen', 'Chibwabwa', '200mg', 'Tablet', 'Oral', 'Take one tablet every 4-6 hours with food'),
	('Cough Syrup', 'Bondwe', '10mg/5ml', 'Syrup', 'Oral', 'Take 10ml every 6-8 hours'),
	('Amoxicillin', 'Chimbulukutumba', '500mg', 'Capsule', 'Oral', 'Take one capsule every 8 hours'),
	('Cetirizine', 'Lula-lula', '10mg', 'Tablet', 'Oral', 'Take one tablet daily'),
	('Paracetamol', 'Zazamina', '500mg', 'Tablet', 'Oral', 'Take one tablet every 4-6 hours'),
	('Metformin', 'Chikanda', '500mg', 'Tablet', 'Oral', 'Take one tablet twice daily with meals'),
	('Lisinopril', 'Insakalabwe', '10mg', 'Tablet', 'Oral', 'Take one tablet daily'),
	('Simvastatin', 'Ubowa', '20mg', 'Tablet', 'Oral', 'Take one tablet daily at bedtime');


INSERT INTO pharmacies (name, city, street, address, phone_number) VALUES
	('Kitwe Pharmacy', 'Chililabombwe', 'Kamenza Road', '1234', '260-977-123-456'),
	('Chipata Pharmacy', 'Ndola', 'Broadway', '5678', '260-977-234-567'),
	('Riverside Pharmacy', 'Kitwe', 'Independence Ave', '9101', '260-977-345-678'),
	('Musonda Pharmacy', 'Livingstone', 'Mosi Road', '2345', '260-977-456-789'),
	('Kopa-street Pharmacy', 'Solwezi', 'Mabanga Road', '6789', '260-977-567-890'),
	('Chimwemwe Pharmacy', 'Kabwe', 'Freedom Way', '4321', '260-977-678-901'),
	('Garneton Pharmacy', 'Mongu', 'Church Road', '8765', '260-977-789-012'),
	('Kawama Pharmacy', 'Kasama', 'Main Street', '3456', '260-977-890-123'),
	('Race-course Pharmacy', 'Chipata', 'Victoria Street', '7890', '260-977-901-234'),
	('Twatasha Pharmacy', 'Mufulira', 'Copperbelt', '6543', '260-977-012-345');


INSERT INTO pharmacy_drugs (pharmacy_name, drug_trade_name, price) VALUES
	('Kitwe Pharmacy', 'Panadol', 10.00),
	('Riverside Pharmacy', 'Aspirin', 5.50),
	('Chipata Pharmacy', 'Ibuprofen', 7.75),
	('Chimwemwe Pharmacy', 'Cough Syrup', 12.00),
	('Musonda Pharmacy', 'Amoxicillin', 15.00),
	('Twatasha Pharmacy', 'Cetirizine', 8.50),
	('Garneton Pharmacy', 'Paracetamol', 9.00),
	('Race-course Pharmacy', 'Metformin', 13.25),
	('Kawama Pharmacy', 'Lisinopril', 14.00),
	('Kopa-street Pharmacy', 'Simvastatin', 11.50);


INSERT INTO prescriptions (patientSSN, doctorSSN, drug_trade_name, date, quantity) VALUES
	('1000000013', '1000000001', 'Panadol', '2024-06-01', 30),
	('1000000011', '1000000005', 'Aspirin', '2024-06-02', 20),
	('1000000019', '1000000005', 'Ibuprofen', '2024-06-03', 25),
	('1000000014', '1000000005', 'Cough Syrup', '2024-06-04', 10),
	('1000000015', '1000000008', 'Amoxicillin', '2024-06-05', 15),
	('1000000016', '1000000003', 'Cetirizine', '2024-06-06', 20),
	('1000000017', '1000000000', 'Paracetamol', '2024-06-07', 30),
	('1000000018', '1000000000', 'Metformin', '2024-06-08', 30),
	('1000000010', '1000000001', 'Lisinopril', '2024-06-09', 20),
	('1000000012', '1000000007', 'Simvastatin', '2024-06-10', 25);


INSERT INTO contracts (pharmacy_name, company_name, start_date, end_date, supervisorSSN) VALUES
	('Kitwe Pharmacy', 'Lusaka Plc', '2024-01-01', '2024-12-31', '1000000000'),
	('Chipata Pharmacy', 'Copperbelt Plc', '2024-02-01', '2024-12-31', '1000000001'),
	('Riverside Pharmacy', 'Luapula Plc', '2024-03-01', '2024-12-31', '1000000002'),
	('Musonda Pharmacy', 'Central Plc', '2024-04-01', '2024-12-31', '1000000003'),
	('Kopa-street Pharmacy', 'Lusaka Plc', '2024-05-01', '2024-12-31', '1000000004'),
	('Chimwemwe Pharmacy', 'Copperbelt Plc', '2024-06-01', '2024-12-31', '1000000005'),
	('Garneton Pharmacy', 'Luapula Plc', '2024-07-01', '2024-12-31', '1000000006'),
	('Kawama Pharmacy', 'Central Plc', '2024-08-01', '2024-12-31', '1000000007'),
	('Race-course Pharmacy', 'Lusaka Plc', '2024-09-01', '2024-12-31', '1000000008'),
	('Twatasha Pharmacy', 'Copperbelt Plc', '2024-10-01', '2024-12-31', '1000000009');


INSERT INTO clause_names (clause_name) VALUES
	('Payment Terms'),
	('Delivery Schedule'),
	('Confidentiality'),
	('Termination');


INSERT INTO contract_clauses (contractID, clause_nameID, clause_text) VALUES
	(1, 1, 'Payment due within 30 days'),
	(1, 2, 'Delivery every Monday'),
	(2, 1, 'Payment due within 45 days'),
	(2, 3, 'Maintain confidentiality of patient records'),
	(3, 2, 'Delivery every Wednesday'),
	(3, 4, 'Contract may be terminated with 60 days notice'),
	(4, 1, 'Payment due within 30 days'),
	(4, 3, 'Maintain confidentiality of patient records'),
	(5, 2, 'Delivery every Friday'),
	(5, 4, 'Contract may be terminated with 30 days notice'),
	(6, 1, 'Payment due within 60 days'),
	(6, 3, 'Maintain confidentiality of business information'),
	(7, 2, 'Delivery every Monday and Friday'),
	(7, 4, 'Contract may be terminated with 90 days notice'),
	(8, 1, 'Payment due within 30 days'),
	(8, 3, 'Maintain confidentiality of patient records'),
	(9, 2, 'Delivery every Tuesday and Thursday'),
	(9, 4, 'Contract may be terminated with 60 days notice'),
	(10, 1, 'Payment due within 45 days'),
	(10, 3, 'Maintain confidentiality of business information');


INSERT INTO payment_methods (method_name) VALUES
	('Cash'),
	('Credit'),
	('PayPal'),
	('Wire Transfer');


INSERT INTO purchases (patientSSN, pharmacy_name, drug_trade_name, purchase_date, quantity, price, payment_methodID) VALUES
	('1000000010', 'Kitwe Pharmacy', 'Panadol', '2024-06-01', 30, 300.00, 1),
	('1000000011', 'Chimwemwe Pharmacy', 'Aspirin', '2024-06-02', 20, 110.00, 1),
	('1000000012', 'Twatasha Pharmacy', 'Ibuprofen', '2024-06-03', 25, 193.75, 1),
	('1000000013', 'Kawama Pharmacy', 'Cough Syrup', '2024-06-04', 10, 120.00, 1),
	('1000000014', 'Kitwe Pharmacy', 'Amoxicillin', '2024-06-05', 15, 225.00, 2),
	('1000000015', 'Kitwe Pharmacy', 'Cetirizine', '2024-06-06', 20, 170.00, 2),
	('1000000016', 'Garneton Pharmacy', 'Paracetamol', '2024-06-07', 30, 270.00, 1),
	('1000000017', 'Riverside Pharmacy', 'Metformin', '2024-06-08', 30, 397.50, 2),
	('1000000018', 'Chipata Pharmacy', 'Lisinopril', '2024-06-09', 20, 280.00, 1),
	('1000000019', 'Musonda Pharmacy', 'Simvastatin', '2024-06-10', 25, 287.50, 1);


INSERT INTO pharmacy_purchases (pharmacy_name, company_name, drug_trade_name, purchase_date, quantity, price, payment_methodID) VALUES
	('Kitwe Pharmacy', 'Lusaka Plc', 'Panadol', '2024-05-01', 500, 5000.00, 1),
	('Chipata Pharmacy', 'Copperbelt Plc', 'Aspirin', '2024-05-02', 400, 2200.00, 2),
	('Riverside Pharmacy', 'Central Plc', 'Ibuprofen', '2024-05-03', 300, 2325.00, 3),
	('Musonda Pharmacy', 'Luapula Plc', 'Cough Syrup', '2024-05-04', 200, 2400.00, 4),
	('Kopa-street Pharmacy', 'Lusaka Plc', 'Amoxicillin', '2024-05-05', 250, 3750.00, 1),
	('Chimwemwe Pharmacy', 'Copperbelt Plc', 'Cetirizine', '2024-05-06', 400, 3400.00, 2),
	('Garneton Pharmacy', 'Central Plc', 'Paracetamol', '2024-05-07', 500, 4500.00, 3),
	('Kawama Pharmacy', 'Copperbelt Plc', 'Metformin', '2024-05-08', 450, 5962.50, 4),
	('Race-course Pharmacy', 'Lusaka Plc', 'Lisinopril', '2024-05-09', 300, 4200.00, 1),
	('Twatasha Pharmacy', 'Central Plc', 'Simvastatin', '2024-05-10', 350, 4025.00, 2);
